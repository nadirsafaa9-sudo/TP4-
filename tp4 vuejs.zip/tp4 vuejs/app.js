const { createApp } = Vue;

createApp({
  data() {
    return {
      tasks: [
        {
          id: 1,
          title: "Apprendre Vue.js 3",
          description: "Lire la documentation officielle et faire quelques exemples.",
          completed: false
        },
        {
          id: 2,
          title: "Créer une mini application",
          description: "Faire une application de gestion des tâches avec Vue.js.",
          completed: true
        },
        {
          id: 3,
          title: "Revoir les directives v-bind et v-for",
          description: "Comprendre comment lier dynamiquement les données.",
          completed: false
        }
      ],
      filters: ["Toutes", "À faire", "Terminées"],
      selectedFilter: "Toutes"
    };
  },
  computed: {
    filteredTasks() {
      if (this.selectedFilter === "À faire") {
        return this.tasks.filter(t => !t.completed);
      } else if (this.selectedFilter === "Terminées") {
        return this.tasks.filter(t => t.completed);
      }
      return this.tasks;
    },
    totalTasks() {
      return this.tasks.length;
    }
  },
  methods: {
    markAsDone(task) {
      task.completed = true;
    }
  }
}).mount("#app");
